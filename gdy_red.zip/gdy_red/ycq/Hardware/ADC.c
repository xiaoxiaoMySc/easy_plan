#include<ADC.h>
#include<stm32f10x.h>
  
uint16_t ADC_Value[4]={0};
float Voltage1=0;
float Voltage2=0;






void ADC_gpio_init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AIN;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}
void ADC_init()
{
	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);

	ADC_InitTypeDef ADC_InitStructure;
ADC_DeInit(ADC1);
	ADC_InitStructure.ADC_Mode=ADC_Mode_Independent;
	ADC_InitStructure.ADC_DataAlign=ADC_DataAlign_Right;
	ADC_InitStructure.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_ContinuousConvMode=ENABLE;
	ADC_InitStructure.ADC_ScanConvMode=ENABLE;
	ADC_InitStructure.ADC_NbrOfChannel=4;
		ADC_Init(ADC1,&ADC_InitStructure);

	ADC_DMACmd(ADC1,ENABLE);
	
			ADC_RegularChannelConfig(ADC1,ADC_Channel_0,1,ADC_SampleTime_28Cycles5);
			ADC_RegularChannelConfig(ADC1,ADC_Channel_1,2,ADC_SampleTime_28Cycles5);
			ADC_RegularChannelConfig(ADC1,ADC_Channel_2,3,ADC_SampleTime_28Cycles5);
			ADC_RegularChannelConfig(ADC1,ADC_Channel_3,4,ADC_SampleTime_28Cycles5);

	ADC_Cmd(ADC1,ENABLE);
	ADC_ResetCalibration(ADC1);
	while(ADC_GetResetCalibrationStatus(ADC1));
	ADC_StartCalibration(ADC1);
	while(ADC_GetCalibrationStatus(ADC1));
}
void DMA_init()
{	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);

	DMA_InitTypeDef DMA_Initstructure;
	DMA_DeInit(DMA1_Channel1);
	DMA_Initstructure.DMA_PeripheralBaseAddr=(uint32_t)&(ADC1->DR);
	DMA_Initstructure.DMA_MemoryBaseAddr=(uint32_t)ADC_Value;
	DMA_Initstructure.DMA_DIR=DMA_DIR_PeripheralSRC;
	DMA_Initstructure.DMA_BufferSize=4;
	DMA_Initstructure.DMA_PeripheralInc=DMA_PeripheralInc_Disable;
	DMA_Initstructure.DMA_MemoryInc=DMA_MemoryInc_Enable;
	DMA_Initstructure.DMA_MemoryDataSize=DMA_MemoryDataSize_HalfWord;
	DMA_Initstructure.DMA_Mode=DMA_Mode_Circular;
	DMA_Initstructure.DMA_M2M=DMA_M2M_Disable;
	DMA_Initstructure.DMA_Priority=DMA_Priority_Medium;
	DMA_Initstructure.DMA_PeripheralDataSize=DMA_PeripheralDataSize_HalfWord;
	DMA_Init(DMA1_Channel1,&DMA_Initstructure);
	DMA_Cmd(DMA1_Channel1,ENABLE);
	

	
}


	