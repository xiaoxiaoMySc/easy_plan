#ifndef _ADC_H
#define _ADC_H
#include<stm32f10x.h>
extern uint16_t ADC_Value[4];
extern float Voltage1;
extern float Voltage2;
 void ADC_gpio_init();
void ADC_init();
void DMA_init();
#endif