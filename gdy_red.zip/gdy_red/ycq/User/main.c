#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"
#include<OLED_Data.h>
#include "NRF24L01.h"
#include<ADC.h>
#include<timer.h>

	uint8_t Buf1[32] = {0,0 } ;

	uint8_t Buf[32] = {4,0,0,0,0 } ;
float fandh=0, fanspeed=0, fandh1=0, fanspeed1=0;
int main(void)
{
	
ADC_gpio_init();
	ADC_init();
	DMA_init();
	OLED_Init();
	NRF24L01_Init();
	TIM_init(TIM3,10000,72);
	TIM_ITSetUp(3);
	
	while (1)
	{		OLED_Clear();
						
OLED_ShowNum(26,0,Buf[1],3,OLED_8X16);
		OLED_ShowNum(100,0,Buf[2],3,OLED_8X16);
		OLED_ShowString1(0,0,"M1:",OLED_8X16);
		OLED_ShowString1(74,0,"M2:",OLED_8X16);
		
		fanspeed=Buf[1];
		
		fandh+=(fanspeed-fandh)/8;
				OLED_DrawRectangle(1,16,10,48-(fandh)/2,OLED_FILLED);
		
			
		fanspeed1=Buf[2];
		
		fandh1+=(fanspeed1-fandh1)/8;
				OLED_DrawRectangle(117,16,126,48-(fandh1)/2,OLED_FILLED);
		OLED_ReverseArea(0,16,11,48);
				OLED_ReverseArea(117,16,128,48);
OLED_DrawLine(0,15,10,15);
		OLED_DrawLine(116,15,128,15);
		OLED_DrawLine(11,15,11,64);
		OLED_DrawLine(116,15,116,64);
OLED_DrawLine(0,15,0,64);
		OLED_DrawLine(127,15,127,64);
		
		OLED_ShowNum(70,35,Buf1[1]-90,3,OLED_8X16);
		OLED_ShowNum(30,35,Buf1[2]-90,3,OLED_8X16);
		
		
		OLED_DrawLine(41,38+(Buf1[2]-90),86,38-(Buf1[2]-90));
		
				OLED_DrawLine(64,20+(Buf1[1]-90),64,48-(Buf1[2]-90));
OLED_ShowFloatNum(60,54,Buf1[3],6,4,OLED_6X8);
		
		OLED_Update();
	}
}

vu16 count;

void TIM3_IRQHandler()
{

	if(TIM_GetITStatus(TIM3,TIM_IT_Update)!=RESET)
	{
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
		count++;
		if(count>=5)
		{
		count=0;
							ADC_SoftwareStartConvCmd(ADC1,ENABLE);
 
		Buf[1]=120-(ADC_Value[1])/17+(120-(ADC_Value[3])/17)/2;
		Buf[2]=120-(ADC_Value[1])/17-(120-(ADC_Value[3])/17)/2;
		
		if(120-(ADC_Value[1])/17+(120-(ADC_Value[3])/17)/2>100)
			Buf[1]=100;
		if(120-(ADC_Value[1])/17+(120-(ADC_Value[3])/17)/2<0)
			Buf[1]=0;
		if(120-(ADC_Value[1])/17-(120-(ADC_Value[3])/17)/2>100)
			Buf[2]=100;
		if(120-(ADC_Value[1])/17-(120-(ADC_Value[3])/17)/2<0)
			Buf[2]=0;
		
		
if (NRF24L01_Get_Value_Flag() == 0)
		{
			NRF24L01_GetRxBuf(Buf1);
		}
	
			NRF24L01_SendBuf(Buf);
		
			
		}
	}
}

		



