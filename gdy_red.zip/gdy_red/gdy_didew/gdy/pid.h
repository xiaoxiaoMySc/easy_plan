#ifndef _pid_h_
#define _pid_h_

#include "stm32f10x.h"

typedef struct
{
    float err;
    float err_last;

    float expect;
    float feedback;

    float kp;
    float ki;
    float kd;

    float integral;
    float integral_max;

    float out;
    float out_max;
}Pid;


typedef struct
{
    //姿态外环（角度环）
    Pid pitAngle;
    Pid rolAngle;
    Pid yawAngle;
	
   
           
}AllPid;

float PidController(Pid *controller);
void AllPidInit(void);
void ClearIntegral(Pid *controller);


#endif
