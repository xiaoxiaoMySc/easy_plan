#ifndef _PWM_H
#define _PWM_H
	void pwm_init();
void pwm_setcompare2(unsigned int compare);
void pwm_setcompare3(unsigned int compare);

void pwm_setcompare1(unsigned int compare);
void pwm_setcompare4(unsigned int compare);
void setangle2(float angle2);
void setangle3(float angle3);
void setangle1(float angle1);
void setangle4(float angle4);
void pwm_init3();
void pwm_setcompare2_3(unsigned int compare);
void pwm_setcompare3_3(unsigned int compare);
void pwm_setcompare1_3(unsigned int compare);
void pwm_setcompare4_3(unsigned int compare);
void setangle2_3(float angle2);
void setangle3_3(float angle3);
void setangle1_3(float angle1);
void setangle4_3(float angle4);
#endif
