#include<pwm.h>
	#include<stm32f10x.h>
	
	void pwm_init()
{GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//RCC->APB1ENR |=RCC_APB1ENR_TIM2EN(????RCC��?????????????
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_0;
	
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//????CR1??��????
TIM_TimeBaseInitStructure.TIM_ClockDivision=0;//CR1
TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;//CR1
	TIM_TimeBaseInitStructure.TIM_Period=1000 - 1;//ARR  TIM2->ARR=20000-1;
	TIM_TimeBaseInitStructure.TIM_Prescaler=8 - 1;//PSC
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);//CR1
	
	
	
	//CCR(?????????????
	TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;//
	TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;//
	TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;//
	TIM_OCInitStructure.TIM_Pulse=0;//TIM2->CCR1=TIM_Pulse;
	
		TIM_OC1Init(TIM2,&TIM_OCInitStructure);

	TIM_OC2Init(TIM2,&TIM_OCInitStructure);
	
	
	TIM_OC3Init(TIM2,&TIM_OCInitStructure);
		TIM_OC4Init(TIM2,&TIM_OCInitStructure);

	TIM_OC1PreloadConfig(TIM2,TIM_OCPreload_Enable);
	
	TIM_OC2PreloadConfig(TIM2,TIM_OCPreload_Enable);
		TIM_OC3PreloadConfig(TIM2,TIM_OCPreload_Enable);
	
	TIM_OC4PreloadConfig(TIM2,TIM_OCPreload_Enable);
	
	TIM_Cmd(TIM2,ENABLE);//TIM2->CR1 |=TIM_CR1_CEN;
}
//????????=CCR/ARR
void pwm_setcompare2(unsigned int compare)
{
	TIM_SetCompare2(TIM2,compare);//change the data of dutyfactor(?????
}

void pwm_setcompare3(unsigned int compare)
{
	TIM_SetCompare3(TIM2,compare);//change the data of dutyfactor(?????
}

void pwm_setcompare1(unsigned int compare)
{
	TIM_SetCompare1(TIM2,compare);
}

void pwm_setcompare4(unsigned int compare)
{
	TIM_SetCompare4(TIM2,compare);
}


//jiao du
void setangle2(float angle2)
{pwm_setcompare2(angle2/180*2000+500);
}

void setangle3(float angle3)
{pwm_setcompare3(angle3/180*2000+500);
}

void setangle1(float angle1)
{pwm_setcompare1(angle1/180*2000+500);
}


void setangle4(float angle4)
{pwm_setcompare4(angle4/180*2000+500);
}







void pwm_init3()
{GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);//RCC->APB1ENR |=RCC_APB1ENR_TIM2EN(????RCC��?????????????
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6|GPIO_Pin_7;
	
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//????CR1??��????
TIM_TimeBaseInitStructure.TIM_ClockDivision=0;//CR1
TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;//CR1
	TIM_TimeBaseInitStructure.TIM_Period=20000 - 1;//ARR  TIM2->ARR=20000-1;
	TIM_TimeBaseInitStructure.TIM_Prescaler=72 - 1;//PSC
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStructure);//CR1
	
	
	
	//CCR(?????????????
	TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;//
	TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;//
	TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;//
	TIM_OCInitStructure.TIM_Pulse=0;//TIM2->CCR1=TIM_Pulse;
	TIM_OCInitStructure.TIM_OutputNState=TIM_OutputNState_Disable;
	TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Set;
		TIM_OC1Init(TIM3,&TIM_OCInitStructure);

	TIM_OC2Init(TIM3,&TIM_OCInitStructure);
	
	
	TIM_OC3Init(TIM3,&TIM_OCInitStructure);
		TIM_OC4Init(TIM3,&TIM_OCInitStructure);

	TIM_OC1PreloadConfig(TIM3,TIM_OCPreload_Enable);
	
	TIM_OC2PreloadConfig(TIM3,TIM_OCPreload_Enable);
		TIM_OC3PreloadConfig(TIM3,TIM_OCPreload_Enable);
	
	TIM_OC4PreloadConfig(TIM3,TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM3,ENABLE);
	TIM_Cmd(TIM3,ENABLE);//TIM2->CR1 |=TIM_CR1_CEN;
}
//????????=CCR/ARR
void pwm_setcompare2_3(unsigned int compare)
{
	TIM_SetCompare2(TIM3,compare);//change the data of dutyfactor(?????
}

void pwm_setcompare3_3(unsigned int compare)
{
	TIM_SetCompare3(TIM3,compare);
}

void pwm_setcompare1_3(unsigned int compare)
{
	TIM_SetCompare1(TIM3,compare);
}

void pwm_setcompare4_3(unsigned int compare)
{
	TIM_SetCompare4(TIM3,compare);
}


//jiao du
void setangle2_3(float angle2)
{pwm_setcompare2_3(angle2/180*2000+500);
}


void setangle3_3(float angle3)
{pwm_setcompare3_3(angle3/180*2000+500);
}

void setangle1_3(float angle1)
{pwm_setcompare1_3(angle1/180*2000+500);
}


void setangle4_3(float angle4)
{pwm_setcompare4_3(angle4/180*2000+500);
}


