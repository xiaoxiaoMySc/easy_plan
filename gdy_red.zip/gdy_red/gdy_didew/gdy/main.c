#include<stm32f10x.h>
#include "NRF24L01.h"
#include<Delay.h>
#include<timer.h>
#include<pwm.h>
#include<ADXL.h>
#include<pid.h>
#include<bmp280.h>
#include<OLED.h>

 struct PWM_ADD{
int motor1;
	int motor2;
	int motor3;
	
	int motor4;
} pwm;

void fz(struct PWM_ADD *Speed,int motor1,int motor2,int motor3,int motor4)
{
Speed->motor1=motor1;
	Speed->motor2=motor2;
Speed->motor3=motor3;
Speed->motor4=motor4;
return;
}
		uint8_t Buf[32] = {0};
uint8_t Buf1[32] = {2,0,0,0};
float x_angle,y_angle,z_angle,Out,Out1;
extern AllPid allPid;

float Pl,T,P;
int main()
{

//// OLED_Init();
	NRF24L01_Init();
	ADXL345_Init();	

pwm_init();
TIM_init(TIM3,10000,72);
	TIM_ITSetUp(3);
	AllPidInit();
	Bmp280Init();

while(1)
{		
		
Pl=bmp280_GetAltitude();
		T=bmp280_T();
				P=bmp280_P();
		
				get_angle(&x_angle,&y_angle,&z_angle);
  
if (NRF24L01_Get_Value_Flag() == 0)
		{
			NRF24L01_GetRxBuf(Buf);
		}
		Buf1[1]=x_angle+90;
				Buf1[2]=y_angle+90;
Buf1[3]=Pl;
				 			NRF24L01_SendBuf(Buf1);

		
	}

}

vu16 count;

void TIM3_IRQHandler()
{

	if(TIM_GetITStatus(TIM3,TIM_IT_Update)!=RESET)   
	{
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
		count++;
		if(count>=0)
		{
			count=0;	
			allPid.rolAngle.expect = 0; 
			                                                                                                                                                                                        0; 

	allPid.rolAngle.feedback =  y_angle;              
		allPid.pitAngle.feedback =  x_angle;               

   Out= PidController(&allPid.rolAngle);
		   Out1= PidController(&allPid.pitAngle);
if(x_angle<-20)
			allPid.pitAngle.expect = -20; 
else
{
			allPid.pitAngle.expect =x_angle;


 Out1=0;			
}			
		fz(&pwm,Buf[1]*10,Buf[2]*10,Buf[1]*10,Buf[2]*10);
		pwm_setcompare1(pwm.motor1+Out-Out1);pwm_setcompare2(pwm.motor2-Out-Out1);pwm_setcompare3(pwm.motor3+Out-Out1);pwm_setcompare4(pwm.motor4-Out-Out1);
			////////////

			
		}
	}
}
                                    
		



