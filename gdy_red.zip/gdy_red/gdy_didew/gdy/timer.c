#include<timer.h>
#include<stm32f10x.h>
void TIM_init(TIM_TypeDef*TIMx,u16 arr,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	if(TIMx==TIM2)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	if(TIMx==TIM3)
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
if(TIMx==TIM4)
				RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
if(TIMx==TIM5)
				RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
TIM_DeInit(TIMx);
TIM_InternalClockConfig(TIMx);
TIM_TimeBaseStructure.TIM_Period=arr-1;
TIM_TimeBaseStructure.TIM_Prescaler=psc-1;
TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;
TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;
TIM_TimeBaseInit(TIMx,&TIM_TimeBaseStructure);
//TIM_ARRPreloadConfig(TIMx,DISABLE);
TIM_ARRPreloadConfig(TIMx,ENABLE);
//TIM_ClearFlag(TIMx,TIM_FLAG_Update);
TIM_ITConfig(TIMx,TIM_IT_Update,ENABLE);
TIM_Cmd(TIMx,ENABLE);
}


void TIM_ITSetUp(u8 timNo)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	switch(timNo)
	{
		case 2:
			NVIC_InitStructure.NVIC_IRQChannel=TIM2_IRQn;
		break;
		case 3:
			NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn;
		break;
	}
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}
