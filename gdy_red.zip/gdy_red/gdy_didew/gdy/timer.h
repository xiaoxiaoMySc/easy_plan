#ifndef _TIMER_H
#define _TIMER_H
#include<stm32f10x.h>


void TIM_init(TIM_TypeDef*TIMx,u16 arr,u16 psc);

void TIM_ITSetUp(u8 timNo);




#endif