#include "pid.h"

AllPid allPid;

//存储pid控制器参数
const float  pidIintData[15][5] =
{
    //0.kp 1.ki 2.kd 3.积分限幅  4.pid输出限幅值  
    //姿态外环参数  
    {28,  0.01,   50,  1000, 	1000},          //俯仰角度值
    {2.5,  0.01,   0.5,  1000,	1000},          //横滚角度值
//    {2.0,  0,   0,  300, 	800},          //偏航角度值
    
   
	
          
};

//pid参数初始化配置
void PidInit(Pid *controller,uint8_t label)
{
    controller->kp  = pidIintData[label][0];
    controller->ki  = pidIintData[label][1];
    controller->kd  = pidIintData[label][2];
    controller->integral_max = pidIintData[label][3];
    controller->out_max = pidIintData[label][4];      
}
//pid参数初始化
void AllPidInit(void)
{
	
	PidInit(&allPid.pitAngle,0);
	PidInit(&allPid.rolAngle,1);
//	PidInit(&allPid.yawAngle,2);
	
	
} 

//pid控制器
float PidController(Pid *controller)
{
    controller->err_last = controller->err;		//保存上次偏差
    controller->err = controller->expect - controller->feedback;		//计算误差
    controller->integral += controller->ki * controller->err;		//误差积分  

    //积分限幅
    if(controller->integral >  controller->integral_max){
			controller->integral =  controller->integral_max;
		}
    if(controller->integral < -controller->integral_max){
			controller->integral = -controller->integral_max;
		}
 
    //pid运算
    controller->out =  controller->kp * controller->err
                     + controller->integral
                     + controller->kd * (controller->err - controller->err_last);
    //输出限幅
    if(controller->out >  controller->out_max)   controller->out =  controller->out_max;
    if(controller->out < -controller->out_max)   controller->out = -controller->out_max;

    return  controller->out;
}
//清除积分
void ClearIntegral(Pid *controller)
{
    controller->integral = 0.0f;
}
